import discord
import requests
import json
import random
import status

client = discord.Client()

@client.event
        # Setting `Watching ` status
async def on_ready():
    print('We have logged in as {0.user}'.format(client))
    await client.change_presence(activity=discord.Activity(type=discord.ActivityType.playing, name="with 2 balls and a stick"))
@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.startswith('hi'):
        await message.channel.send('shut the fuck up!')
    if message.content.startswith('shut up'):
        await message.channel.send('eat my ass')
    if message.content.startswith('send hands'):
        await message.channel.send('please send hands with veins, we are desperate')
    if message.content.startswith('Lj'):
        await message.channel.send('Lj: HEAD MILF HUNTER')
    if message.content.startswith('lj'):
        await message.channel.send('Lj: HEAD MILF HUNTER')
    if message.content.startswith('FUCK YOU'):
        await message.channel.send('no, fuck *YOU*')
    if message.content.startswith('fuck you'):
        await message.channel.send('no, fuck *YOU*')
    if message.content.startswith('sexy'):
        await message.channel.send('That word is not allowed here.')
    if message.content.startswith('ur mom'):
        await message.channel.send('2 balls and a stick')
    if message.content.startswith('gloria'):
        await message.channel.send('uncle enrique is my moms boyfriend')
    if message.content.startswith('happy birthday'):
        await message.channel.send('its not your birthday')
    if message.content.startswith('what'):
        await message.channel.send('sniff my balls')
    if message.content.startswith('wtf'):
        await message.channel.send('dumbass')
    if message.content.startswith('buy me nitro'):
        await message.channel.send('enjoy poverty')
    if message.content.startswith('amelia'):
        await message.channel.send('amelia is ljs top milf')
    if message.content.startswith('furry'):
        await message.channel.send('https://cdn.discordapp.com/emojis/805697577076260884.png?v=1')
    if message.content.startswith('transformice'):
        await message.channel.send('that game sucks balls')
    if message.content.startswith('xd'):
        await message.channel.send('furry talk')
    if message.content.startswith('balls'):
        await message.channel.send('suck my balls')
    if message.content.startswith('send hands'):
        await message.channel.send('https://cdn.discordapp.com/attachments/721111636286374028/887895990760247327/resize.png')
client.run('Nzk5NTQyNDU1NTA2MDQyOTAw.YAFF8A.aqbf6LFpDBaSBSFxU89gRmW3oTs')